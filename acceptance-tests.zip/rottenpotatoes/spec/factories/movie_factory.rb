FactoryGirl.define do
  factory :movie do
    title 'No name'
    rating 'PG'
    description 'No description'
    release_date '2016-04-23'
  end
end